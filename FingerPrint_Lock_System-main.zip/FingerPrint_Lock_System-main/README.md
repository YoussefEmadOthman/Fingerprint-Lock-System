# FingerPrint_Lock_System
This repository contains code and diagram for Fingerprint lock system using Arduino
